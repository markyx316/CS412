### Angular App Assignment

- Please see the weatherApp folder for the Angular App I built for this assignment.

- The remaining files are for the Node App I built to fetch the weather data.